package test;

import dominio.*;
import static org.junit.Assert.*;

import dominio.pokemon.Pokemon;
import org.junit.Before;
import org.junit.Test;

public class PokemonTest {
    private Pokemon pikachu;
    private Movimiento impactrueno;

    @Test
    public void testRecibirDanio() {
        pikachu.recibirDanio(50);
        assertEquals(150, pikachu.getPs());
    }

    @Test
    public void testRecibirDanioExcesivo() {
        pikachu.recibirDanio(250);
        assertEquals(0, pikachu.getPs());
    }

    @Test
    public void testAprenderMovimiento() {
        Movimiento movimiento = pikachu.getMovimiento(0);
        assertNotNull(movimiento);
        assertEquals("Impactrueno", movimiento.getNombre());
    }
}