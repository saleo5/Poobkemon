package dominio.exceptions;

public class ModoNoDisponibleException extends Exception {
    public ModoNoDisponibleException(String message) {
        super(message);
    }
}